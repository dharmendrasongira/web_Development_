export default {
  plugins: {
    tailwindcss: {},  // Initialize TailwindCSS
    autoprefixer: {}, // Add vendor prefixes
  },
};
